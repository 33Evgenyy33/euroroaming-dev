<!-- Confirm box -->
<div class="md-modal md-dynamicmodal md-message" id="modal-confirm-box">
    <div class="md-content" id="modal-confirm-box-content">
    </div>
</div>
