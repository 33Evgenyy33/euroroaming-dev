<?php
include_once( 'header.php' );
include_once( 'html-registers.php' ); 
include_once( 'footer.php' ); 
?>