<?php
do_action( 'admin_print_styles' );
do_action( 'admin_print_scripts' );
?>
<div class="content">

</div>
