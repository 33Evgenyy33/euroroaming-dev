<div class="md-modal md-dynamicmodal md-message" id="modal-redirect-payment">
    <div class="md-content">
        <div>
            <div class="sa-icon sa-success md-message-icon">
		      <span class="dashicons dashicons-admin-links"></span>
		    </div>
	        <div id="payment_result_message"></div>
        </div>
    </div>
</div>