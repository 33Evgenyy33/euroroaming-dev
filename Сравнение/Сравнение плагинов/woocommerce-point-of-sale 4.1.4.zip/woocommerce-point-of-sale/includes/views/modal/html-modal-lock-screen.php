<div class="md-modal md-dynamicmodal md-message" id="modal-lock-screen">
    <div class="md-content">
        <div>
            <div class="md-message-icon">
		    	<span class="dashicons dashicons-unlock"></span>
		    </div>
		    <p><?php _e('Enter password to unlock', 'wc_point_of_sale'); ?></p>
		    <input type="password" id="unlock_password" autocomplete="off" style="margin-right: 1em;">
		    <button class="button button-primary" id="unlock_button"><?php _e('Unlock', 'wc_point_of_sale'); ?></button>
        </div>
    </div>
</div>