<?php
$classFile = 'BCGupcext2.barcode.php';
$className = 'BCGupcext2';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.2.0';
?>